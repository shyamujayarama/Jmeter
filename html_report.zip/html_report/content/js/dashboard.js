/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.6296791443850267, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "OrangeLive-5"], "isController": false}, {"data": [0.0, 500, 1500, "OrangeLive-6"], "isController": false}, {"data": [0.07142857142857142, 500, 1500, "OrangeLive-3"], "isController": false}, {"data": [0.0, 500, 1500, "OrangeLive"], "isController": false}, {"data": [0.05714285714285714, 500, 1500, "OrangeLive-4"], "isController": false}, {"data": [0.5, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet"], "isController": false}, {"data": [1.0, 500, 1500, "Login-0"], "isController": false}, {"data": [0.9833333333333333, 500, 1500, "Login-1"], "isController": false}, {"data": [1.0, 500, 1500, "Login-2"], "isController": false}, {"data": [1.0, 500, 1500, "Login-3"], "isController": false}, {"data": [0.9, 500, 1500, "EmployeeList"], "isController": true}, {"data": [1.0, 500, 1500, "Login-4"], "isController": false}, {"data": [1.0, 500, 1500, "Login-5"], "isController": false}, {"data": [1.0, 500, 1500, "Login-6"], "isController": false}, {"data": [0.5, 500, 1500, "Logout"], "isController": true}, {"data": [0.0, 500, 1500, "Home"], "isController": true}, {"data": [1.0, 500, 1500, "HTTP Request-6"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request-3"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-6"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request-2"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request-5"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request-4"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request-1"], "isController": false}, {"data": [1.0, 500, 1500, "HTTP Request-0"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-1"], "isController": false}, {"data": [0.5161290322580645, 500, 1500, "Login"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-0"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-3"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-2"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-5"], "isController": false}, {"data": [1.0, 500, 1500, "https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-4"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.9857142857142858, 500, 1500, "OrangeLive-1"], "isController": false}, {"data": [0.6142857142857143, 500, 1500, "OrangeLive-2"], "isController": false}, {"data": [0.5, 500, 1500, "HTTP Request"], "isController": false}, {"data": [0.4857142857142857, 500, 1500, "OrangeLive-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 648, 0, 0.0, 1580.814814814814, 0, 14119, 340.5, 5281.500000000004, 8171.349999999998, 12877.819999999998, 12.641435817401483, 4869.546871951815, 13.067076850858369], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["OrangeLive-5", 35, 0, 0.0, 5140.057142857144, 1665, 12734, 4508.0, 10609.8, 11933.199999999995, 12734.0, 0.700308135579655, 793.6412920122353, 0.4164918501640722], "isController": false}, {"data": ["OrangeLive-6", 35, 0, 0.0, 5688.5999999999985, 1506, 13016, 4407.0, 11706.199999999999, 12758.399999999998, 13016.0, 0.6963788300835655, 992.6308974582173, 0.40735441330083566], "isController": false}, {"data": ["OrangeLive-3", 35, 0, 0.0, 3430.371428571429, 996, 11266, 2257.0, 7851.799999999999, 9265.999999999989, 11266.0, 0.7062146892655368, 360.2108712923729, 0.42138396009887], "isController": false}, {"data": ["OrangeLive", 35, 0, 0.0, 7838.285714285715, 2950, 14119, 7517.0, 13612.8, 13999.8, 14119.0, 0.6827936012485368, 2426.242497652897, 2.7171718018435427], "isController": false}, {"data": ["OrangeLive-4", 35, 0, 0.0, 2862.3142857142857, 1192, 8470, 2077.0, 5538.399999999995, 8072.399999999998, 8470.0, 0.7103281716152863, 339.3086453597812, 0.4169015929109248], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet", 6, 0, 0.0, 830.3333333333334, 770, 969, 805.0, 969.0, 969.0, 969.0, 0.2880184331797235, 3.071305938580069, 1.308740009360599], "isController": false}, {"data": ["Login-0", 30, 0, 0.0, 175.9333333333333, 163, 217, 173.0, 191.60000000000002, 203.79999999999998, 217.0, 1.1211600269078408, 1.1540065120711562, 0.785030995403244], "isController": false}, {"data": ["Login-1", 30, 0, 0.0, 350.3, 317, 508, 337.0, 384.6, 452.99999999999994, 508.0, 1.1137924633376648, 4.693917358919622, 0.6961202895860406], "isController": false}, {"data": ["Login-2", 30, 0, 0.0, 171.30000000000004, 158, 194, 170.0, 182.0, 188.5, 194.0, 1.1218727796267902, 1.085718676377099, 0.8063460603567556], "isController": false}, {"data": ["Login-3", 30, 0, 0.0, 171.2666666666666, 162, 191, 170.0, 184.5, 189.35, 191.0, 1.1219147344801794, 1.0879505188855647, 0.8195236537023187], "isController": false}, {"data": ["EmployeeList", 30, 0, 0.0, 166.06666666666666, 0, 969, 0.0, 813.0, 910.1499999999999, 969.0, 1.1280740016545086, 2.4058601681770324, 1.025181314394224], "isController": true}, {"data": ["Login-4", 30, 0, 0.0, 173.0333333333334, 158, 213, 171.0, 187.8, 206.95, 213.0, 1.1212857409829937, 1.087340567183704, 0.8081141375443842], "isController": false}, {"data": ["Login-5", 30, 0, 0.0, 171.36666666666667, 160, 197, 169.0, 183.60000000000002, 193.7, 197.0, 1.122334455667789, 1.0894535634118967, 0.8187342171717171], "isController": false}, {"data": ["Login-6", 30, 0, 0.0, 171.53333333333336, 158, 197, 170.5, 181.0, 188.75, 197.0, 1.1207830537602272, 1.0879476127320955, 0.806657334591101], "isController": false}, {"data": ["Logout", 6, 0, 0.0, 804.3333333333333, 792, 841, 798.0, 841.0, 841.0, 841.0, 0.2877421830040284, 3.0688284547045845, 0.9607329332917706], "isController": true}, {"data": ["Home", 32, 0, 0.0, 8257.156249999998, 3033, 14119, 8010.0, 13698.9, 14022.8, 14119.0, 0.7725922885632198, 2745.650230910029, 3.074524976460079], "isController": true}, {"data": ["HTTP Request-6", 6, 0, 0.0, 170.66666666666666, 161, 183, 167.5, 183.0, 183.0, 183.0, 0.2964426877470356, 0.28775784337944665, 0.14851083868577075], "isController": false}, {"data": ["HTTP Request-3", 6, 0, 0.0, 170.83333333333334, 158, 197, 165.0, 197.0, 197.0, 197.0, 0.2964719833975689, 0.2874967573376816, 0.15171027275422472], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-6", 6, 0, 0.0, 179.83333333333334, 161, 202, 179.0, 202.0, 202.0, 202.0, 0.29691211401425177, 0.2882135169239905, 0.19948782660332542], "isController": false}, {"data": ["HTTP Request-2", 6, 0, 0.0, 169.33333333333331, 159, 178, 168.5, 178.0, 178.0, 178.0, 0.2963548355230663, 0.28680433789390497, 0.14817741776153315], "isController": false}, {"data": ["HTTP Request-5", 6, 0, 0.0, 173.5, 159, 192, 169.0, 192.0, 192.0, 192.0, 0.2964133978855844, 0.2877294116194052, 0.15139082724039127], "isController": false}, {"data": ["HTTP Request-4", 6, 0, 0.0, 167.83333333333334, 161, 176, 168.0, 176.0, 176.0, 176.0, 0.29645733484855974, 0.28748255225060526, 0.14880768565640595], "isController": false}, {"data": ["HTTP Request-1", 6, 0, 0.0, 346.0, 322, 360, 348.5, 360.0, 360.0, 360.0, 0.29395913967958454, 1.239039687545931, 0.11942090049483121], "isController": false}, {"data": ["HTTP Request-0", 6, 0, 0.0, 273.8333333333333, 257, 303, 271.0, 303.0, 303.0, 303.0, 0.29531919082541713, 0.4729721415563321, 0.12026181892011616], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-1", 6, 0, 0.0, 356.16666666666663, 316, 457, 337.5, 457.0, 457.0, 457.0, 0.2947099562846898, 1.2417247132717717, 0.17009139078540203], "isController": false}, {"data": ["Login", 62, 0, 0.0, 687.0967741935484, 0, 877, 696.0, 773.6000000000001, 812.0, 877.0, 1.637396012148422, 15.992000775782383, 7.834679948501254], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-0", 6, 0, 0.0, 277.83333333333337, 259, 308, 270.0, 308.0, 308.0, 308.0, 0.29609159099881566, 0.47420918870904066, 0.17378031854520332], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-3", 6, 0, 0.0, 176.33333333333334, 162, 199, 176.0, 199.0, 199.0, 199.0, 0.29670655721491446, 0.28772422979922857, 0.20253699559885271], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-2", 6, 0, 0.0, 170.66666666666666, 167, 174, 171.0, 174.0, 174.0, 174.0, 0.29708853238265004, 0.2875143902257873, 0.19931623217468805], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-5", 6, 0, 0.0, 185.0, 164, 211, 179.5, 211.0, 211.0, 211.0, 0.29653059207274884, 0.2878431723831175, 0.20212729811208854], "isController": false}, {"data": ["https://opensource-demo.orangehrmlive.com/index.php/time/viewMyTimesheet-4", 6, 0, 0.0, 177.33333333333334, 164, 199, 173.0, 199.0, 199.0, 199.0, 0.29670655721491446, 0.28772422979922857, 0.19963947062605084], "isController": false}, {"data": ["Debug Sampler", 32, 0, 0.0, 0.25, 0, 1, 0.0, 1.0, 1.0, 1.0, 0.8451076191733792, 0.3462135217219068, 0.0], "isController": false}, {"data": ["OrangeLive-1", 35, 0, 0.0, 352.6285714285715, 320, 502, 346.0, 377.2, 404.39999999999947, 502.0, 0.7291210965981292, 3.1437447594421184, 0.3837854209632731], "isController": false}, {"data": ["OrangeLive-2", 35, 0, 0.0, 592.1999999999997, 169, 1347, 570.0, 754.4, 1343.0, 1347.0, 0.7316971192039136, 1.1961532983860852, 0.42944332875151564], "isController": false}, {"data": ["HTTP Request", 6, 0, 0.0, 804.3333333333333, 792, 841, 798.0, 841.0, 841.0, 841.0, 0.2877421830040284, 3.0688284547045845, 0.9607329332917706], "isController": false}, {"data": ["OrangeLive-0", 35, 0, 0.0, 773.8000000000001, 660, 1892, 728.0, 841.4, 1232.7999999999965, 1892.0, 0.7248327707250399, 0.746068105804875, 0.36453991887050347], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 648, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
